//
// Sample code for APEX by Jhon
// This allows switching between side and top navigation at run time.

var dpnm = {
    init:function(){
    "use strict";
    
    var da=this;
    apex.debug.log('adnm.init',da);
    var l_navBarClass = da.action.attribute01;
    var l_navMenuItemLabel = da.action.attribute02;
    var l_navMenuItemIcon = da.action.attribute03;
    var badgeRE = /\[(.*)\]/; // pattern for finding badge text in a label
    var isSideNav = true; // we know this is initially how the page is rendered

    /*
     * When the navigation shifts around on the page the layout changes in ways that can affect other
     * regions and components. Examples include sticky widgets and sticky table headers.
     * This function lets others know about the change so they can adjust.
     */
    function updateStickyThings() {
        setTimeout(function() {
            apex.theme42.util.fixLayout(); // undocumented UT API
            $(window).trigger("apexwindowresized");
            $(window).trigger("resize");
        }, 201); // this number comes from theme42.js
    }

    /*
     * Turn a tree into a menu. Called recursivly to process the whole tree.
     */
    function convertTreeToMenu(treeRoot, level) {
        var i, n, item, m,
        items = [];

        for( i = 0; i < treeRoot.children.length; i++ ) {
            n = treeRoot.children[i];
            item = {
                type: "action", // assume it is an action
                label: n.label
            };
            if (n.id) {
                item.id = n.id;
            }
            if (n.link) {
                item.href = n.link;
                if (n.linkTarget) { // new in 20.1
                    item.target = n.linkTarget;
                }
            }
            // menu widget doesn't support icons on menu bar items. Avoid warning by not setting
            if (n.icon && level > 0) {
                item.icon = n.icon;
            }
            if (level > 0) {
                // missuse the menu accelerator to show a badge
                m = item.label.match(badgeRE);
                if (m && m[1]) {
                    item.label = item.label.replace(badgeRE, "");
                    item.accelerator = m[1];
                }
            }
            if (n.isDisabeld) {
                item.disabled = n.isDisabled;
            }
            // a node that has children becomes a sub menu
            if (n.children && n.children.length) {
                item.type = "subMenu";
                item.menu = {
                    items: convertTreeToMenu(n, level + 1)
                };
                if (level > 0 && item.href) {
                    // this node is both a sub menu and has an href which isn't supported in a menu
                    // so add a new first item to the sub menu with the same name that has the href action
                    item.menu.items.unshift({
                        type: "action",
                        href: item.href,
//                        linkTarget: item.linkTarget, // probably not needed
                        label: item.label,
                    });
                    delete item.href;
                }
            }
            if (n.current) {
                item.current = true;
            }
            items.push(item);
        }
        return items;
    }

    function toTopNav() {
        var tree$, treeRoot,
            menu$ = $("#t_MenuNav");

        $("body").removeClass("apex-side-nav t-PageBody--leftNav")
            .addClass("apex-top-nav");
        isSideNav = false;
        if (menu$.length < 1) {
            // just the first time a menu needs to be inserted in the DOM and initialized.
            tree$ = $("#t_TreeNav");
            treeRoot = tree$.treeView("getNodeAdapter").root();
            // class show-badges turns on a custom css rule to show the menu accelerator text with badge formatting
            menu$ = $('<div class="t-Header-nav-list show-badges" id="t_MenuNav" ></div>');
            $(".t-Header-nav").prepend(menu$);
            menu$.menu({
                menubar: true,
                items: convertTreeToMenu(treeRoot, 0),
                // TODO customize these options and othrs if desired
                behaveLikeTabs: true,
                callout: true,
                menubarOverflow: true,
                menubarShowSubMenuIcon: true
            });
        }
        updateStickyThings();
    }

    function toSideNav() {
        $("body").removeClass("apex-top-nav")
            .addClass("apex-side-nav t-PageBody--leftNav");
        isSideNav = true;
        updateStickyThings();
    }

    function autoNav() {
        // apex.theme.mq is new in 20.1 prior to that use apex.theme42.util.mq
        if ( apex.theme42.util.mq( "(min-width: 440px)" ) ) {
            if (!isSideNav) {
                toSideNav();
            }
        } else {
            if (isSideNav) {
                toTopNav();
            }
        }
    }

    // when the DOM is ready
   // $(function() {
        var navPosStorage = apex.storage.getScopedSessionStorage({}),
            body$ = $("body"),
            navPos = "side"; // one of side, top, auto

        // first check if there is no navigation; if so nothing more to do.
        if (!((body$.hasClass("apex-side-nav") || body$.hasClass("apex-top-nav")) && $("#t_TreeNav").length)) {
            return;
        }
        // load saved nav position setting
        navPos = navPosStorage.getItem("navPos");
        // never trust browser storage. validate!
        if (!navPos || !navPos.match(/top|side|auto/)) {
            navPos = "side"; // default
        }

        if (navPos === "top") {
            toTopNav();
        } else if (navPos === "auto") {
            autoNav();
        } // else should already be side

        apex.actions.add([
            {
                name: "choose-nav-pos",
                label: l_navMenuItemLabel ,//"Navigation Position",
                choices: [
                    {
                        label: "Side",
                        icon: "fa fa-layout-nav-left-hamburger",
                        shortcut: "Ctrl+/,S",
                        value: "side"
                    },
                    {
                        label: "Top",
                        icon: "fa fa-layout-header",
                        shortcut: "Ctrl+/,T",
                        value: "top"
                    },
                    {
                        label: "Auto",
                        icon: "fa fa-mobile",
                        shortcut: "Ctrl+/,A",
                        value: "auto"
                    }
                ],
                set: function(v) {
                    navPos = v;
                    if (navPos === "top" && isSideNav) {
                        toTopNav();
                    } else if (navPos === "side" && !isSideNav) {
                        toSideNav();
                    } else if (navPos === "auto") {
                        autoNav();
                    }
                    navPosStorage.setItem("navPos", navPos);
                },
                get: function() {
                    return navPos;
                }
            }
        ]);

        // Update the username menu in the nav bar to include a sub menu for setting the navigation menu possition
        // wait until UT initializes the menu
        $(window).on("theme42ready", function() {
            var menu$,
                menuId = $(".t-NavigationBar-item." +l_navBarClass +" .js-menuButton").attr("data-menu");

            if (menuId) {
                menu$ = $("#" + menuId);
                menu$.menu("option", "items").unshift({
                    type: "subMenu",
                    label: l_navMenuItemLabel,
                    icon: "fa " + l_navMenuItemIcon,
                    menubarShowSubMenuIcon: true,
                    menu: {
                        items: [
                            {
                                type: "radioGroup",
                                action: "choose-nav-pos"
                            }
                        ]
                    }
                });
            }
        }).on( "apexwindowresized", function() {
            // Update navigation position when the window size changes if auto
            if ( navPos === "auto" ) {
                autoNav();
            }
        });

   // });

}};
